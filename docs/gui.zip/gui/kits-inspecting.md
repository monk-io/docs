---
title: Inspecting Kits
---

After first deployment when the project is running it is possible to inspect the running kits by simply clicking on them. You can access basic CPU, memory and disk usage stats of a kit, check its network endpoints and read the logs from the **Kit Configuration** panel at any time. This is meant for a quick preview - more options are available in the **Monitor** tab of your environment. See Monitoring your project.

To view kit’s network endpoints select the kit by clicking on it, **Kit Configuration** panel will appear. Select **Network** tab on the **Kit Configuration** panel. You can copy the endpoint address or visit it new tab by clicking “Preview” next to the endpoint.

![](/img/docs/gui/Screenshot 2023-03-07 at 18.21.09.png)

To view metrics of a kit select the kit by clicking on it, **Kit Configuration** panel will appear. Select **Metrics** tab on the **Kit Configuration** panel. Metrics are updated in real-time and show current values as well as historical values on a mini graph.

![](/img/docs/gui/Screenshot 2023-03-05 at 22.05.32.png)

To view kit’s logs select the kit by clicking on it, **Kit Configuration** panel will appear. Select **Logs** tab on the **Kit Configuration** panel. Logs are streamed in real-time.

![](/img/docs/gui/Screenshot 2023-03-07 at 18.07.55.png)
