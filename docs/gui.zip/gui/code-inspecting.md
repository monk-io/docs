---
title: Inspecting The Code
---

When working on a system in the Build view, any change made to the instances, kits and connections is dynamically reflected as Monkscript code. In fact, the editable diagram corresponds 1:1 with the code available in **Code preview** tab.

To preview the code click **\[^\]** in the bottom right corner of the screen. This opens code preview panel. The code can be searched and copied.

![](/img/docs/gui/Screenshot 2023-03-07 at 18.23.43.png)
