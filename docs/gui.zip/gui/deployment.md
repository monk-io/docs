---
title: Deploying Your Project
---

Once your design has been set up it is time to **Deploy** it onto your cloud account. The process is fully automated and only requires pressing a button.

Make sure that the kits are connected and placed appropriately and click the **Deploy** button on the top-right of the screen.

![](/img/docs/gui/Screenshot 2023-03-05 at 15-50-15 Tutorial - Monk.png)

Kits turn gray indicating that they are not yet deployed. On the right side of the screen there is a deployment checklist that shows deployment tasks in real time as they progress.

![](/img/docs/gui/Screenshot 2023-03-05 at 15-50-44 Tutorial - Monk.png)

During a successful deployment kits will turn green one by one indicating that they started without issues. In case some kits didn’t start they will turn red. Kits can also become yellow indicating a warning. Hovering over a red or yellow kit reveals a list of problems.

![](/img/docs/gui/Screenshot 2023-03-05 at 21-31-58 Tutorial - Monk.png)